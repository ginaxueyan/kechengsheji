﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class 玩家开始 : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {


    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        int i; int m = 0;
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        string strsql = "select * from Table3";
        SqlDataAdapter da = new SqlDataAdapter(strsql, conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "student");

        int h = ds.Tables["student"].Rows.Count;
        for (i = 0; i < h; i++)
        {
            if (TextBox2.Text == ds.Tables["student"].Rows[i][3].ToString().Trim())
            {
                Label1.Text = ds.Tables["student"].Rows[i + 1][3].ToString().Trim();
                m = 1;
            }
        }
        if (m != 1)
        {
            
            Response.Write("<script>alert('你赢了！')</script>");
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("首页.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
      
    }
}
