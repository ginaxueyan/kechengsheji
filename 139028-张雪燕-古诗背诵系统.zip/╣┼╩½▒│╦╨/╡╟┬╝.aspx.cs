﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class 登录 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        string username = txtusername.Text.Trim();
        string pwd = txtmima.Text.Trim();
        string sql = "select count(*) from userinfo where uname=@uname and upw=@upw";
        SqlCommand cmd = new SqlCommand(sql, conn);
        conn.Open();
        cmd.Parameters.Add(new SqlParameter("uname", txtusername.Text));
        cmd.Parameters.Add(new SqlParameter("upw", txtmima.Text));
        int ret = (int)cmd.ExecuteScalar();
        conn.Close();
        if (ret <= 0)

            Response.Write("<script>alert('登录失败！用户名或密码错误！')</script>");

        else
        {
            Session["username"] = username;
            if (Request.QueryString["flag"] == null)
            {
                Response.Redirect("首页.aspx");
            }
        }
    }
}