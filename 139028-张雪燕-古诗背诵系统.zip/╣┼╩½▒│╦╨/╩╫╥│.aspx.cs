﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class 首页 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel1.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["first"] = 1;
        Response.Redirect("机器开始.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session["first"] = 2;
        Response.Redirect("玩家开始.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session["first"] = 3;
        Response.Redirect("背诵整首诗.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("注册.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("登录.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("管理员登录.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Panel1.Visible=true;
    }
}