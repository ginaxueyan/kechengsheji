﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//using System.Data.OleDb;
public partial class 背诵整首诗 : System.Web.UI.Page
{

   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
           
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {//机器诗句提交
        
        int i;
        int m = 0;
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        string strsql = "select * from Table3";
        SqlDataAdapter da = new SqlDataAdapter(strsql, conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "student");

        int h = ds.Tables["student"].Rows.Count;


        for (i = 0; i < h; i++)
        {
            if (TextBox1.Text == ds.Tables["student"].Rows[i][3].ToString().Trim())
            {
                Label6.Text = ds.Tables["student"].Rows[i + 1][3].ToString().Trim();
                TextBox1.Text = "";
                m = 1;

            }
            if (m != 1)
            {
                TextBox1.Text = "";
                Response.Write("<script>alert('你赢了！')</script>");
            }

        }
       
    }
    


    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        Panel1.Visible = false;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Panel2.Visible = false;
        Panel1.Visible = true;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
       
        
        
    }
    protected void Button5_Click(object sender, EventArgs e)
    {//玩家先输入提交

        int i; int m = 0;
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        string strsql = "select * from Table3";
        SqlDataAdapter da = new SqlDataAdapter(strsql, conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "student");

        int h = ds.Tables["student"].Rows.Count;
        for (i = 0; i < h; i++)
        {
            if (TextBox2.Text == ds.Tables["student"].Rows[i][3].ToString().Trim())
            {
                Label8.Text = ds.Tables["student"].Rows[i + 1][3].ToString().Trim();
                Label4.Text = ds.Tables["student"].Rows[i + 1][1].ToString().Trim();
                m = 1;
            }
        }
        if (m != 1)
        {
            TextBox2.Text = "";
            Response.Write("<script>alert('你赢了！')</script>");
        }
      
}
    
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("首页.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {//机器开始出题
        Panel3.Visible = true;
        SqlConnection conn = new SqlConnection();//建立数据库连接对象conn
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from Table3  where 句号=1 ", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "student");
        Random rn = new Random();
        int n = rn.Next(0, ds.Tables["student"].Rows.Count);
        Label6.Text = ds.Tables["student"].Rows[n][3].ToString();
        Label7.Text = ds.Tables["student"].Rows[n][1].ToString();
        TextBox1.Text = "";

    }
    protected void Button8_Click(object sender, EventArgs e)
    {//玩家先输入出题
        SqlConnection conn = new SqlConnection();//建立数据库连接对象conn
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from Table3  where 句号=1 ", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "student");
        Random rn = new Random();
        int n = rn.Next(0, ds.Tables["student"].Rows.Count);
        Label4.Text = ds.Tables["student"].Rows[n][1].ToString();
    }
}
