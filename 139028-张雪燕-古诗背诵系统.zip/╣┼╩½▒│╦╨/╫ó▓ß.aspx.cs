﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class 注册 : System.Web.UI.Page
{
    protected void bind()
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from userinfo", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "userinfo");
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            bind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlCommand sr = new SqlCommand("select * from userinfo", conn);
        SqlDataAdapter da = new SqlDataAdapter(sr);
        DataSet ds = new DataSet();
        da.Fill(ds, "userinfo");
        DataRow newRow = ds.Tables["userinfo"].NewRow();
        newRow["uname"] = txtname.Text;  //该行另外一列的值
        newRow["upw"] = txtmima.Text;  //该行的一列的值
        newRow["uqq"] = txtnum2.Text;
        newRow["uadd"] = txtaddress.Text;
        ds.Tables["userinfo"].Rows.Add(newRow);
        SqlCommandBuilder cb = new SqlCommandBuilder(da);
        da.Update(ds, "userinfo");
        bind();
        Response.Redirect("首页.aspx");
    }

}