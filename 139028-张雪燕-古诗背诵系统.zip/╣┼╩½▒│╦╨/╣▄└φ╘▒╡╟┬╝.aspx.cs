﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class 管理员登录 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
        SqlConnection conn = new SqlConnection(str);
        string username = txtname.Text.Trim();
        string pwd = txtmima.Text.Trim();
       
        string sql = "select count(*) from admin where username=@username and pwd=@pwd";
        SqlCommand cmd = new SqlCommand(sql, conn);
        conn.Open();
        cmd.Parameters.Add(new SqlParameter("username", txtname.Text));
        cmd.Parameters.Add(new SqlParameter("pwd", txtmima.Text));
      
        int ret = (int)cmd.ExecuteScalar();
        conn.Close();
        if (ret <= 0)

            Response.Write("<script>alert('登录失败！用户名或密码错误！')</script>");

        else
        {
            Session["username"] = username;
            Response.Redirect("更改信息.aspx");
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("首页.aspx");
    }
}