﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class 更改信息 : System.Web.UI.Page
{


    protected void bind()
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from Table3", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "Table3");
        GridView4.DataSource = ds.Tables["Table3"];
        GridView4.DataBind();

    }
    //修改用户信息
    private void databind()
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from userinfo", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "userinfo");
        GridView3.DataSource = ds.Tables[0];
        GridView3.DataBind();
    }
    //删除诗句
    private void databind8()
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from Table3", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "Table3");
        GridView4.DataSource = ds.Tables["Table3"];
        GridView4.DataBind();
    }
    private void databind1()
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from Table3", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "student");
        //GridView3.DataSource = ds.Tables[0];
        //GridView2.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        LinkButton lbt_yonghu1 = (LinkButton)Master.FindControl("yonghu");
        LinkButton lbt_shangpin1 = (LinkButton)Master.FindControl("shangpin");
        lbt_yonghu1.Click += new EventHandler(lbt_yonghu1_Click);
        lbt_shangpin1.Click += new EventHandler(lbt_shangpin1_Click);

        if (!IsPostBack)
            bind();
        Panel2.Visible = false;
      
    }
    protected void lbt_yonghu1_Click(object sender, EventArgs e)
    {
        GridView3.Visible = true;
        Panel2.Visible = false;
        Panel1.Visible = true; databind();
        Panel3.Visible = false;
    }
    protected void lbt_shangpin1_Click(object sender, EventArgs e)
    {
       
        Panel2.Visible = true; databind1();
        GridView3.Visible = false;
        Panel1.Visible = false;
        Panel3.Visible = false;
    }
    //修改用户信息
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        string SelectSql = "select * from userinfo  where uname='" + DropDownList3.SelectedValue + "'";
        SqlDataAdapter da = new SqlDataAdapter(SelectSql, conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "userinfo");
        DataRow MyRow = ds.Tables["userinfo"].Rows[0];   //得到要修改的行
        MyRow["uname"] = txtname.Text;    //为相应字段赋以新值
        MyRow["upw"] = txtmima.Text;
        MyRow["uqq"] = txtid.Text;
        MyRow["uadd"] = txtadd.Text;
        SqlCommandBuilder cb = new SqlCommandBuilder(da);
        da.Update(ds, "userinfo");			//将DataSet中数据变化提交到数据库（更新数据库）
        Response.Write("<script> alert('更新成功！');</script>");
        GridView3.DataBind();
    }
protected void  DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
{
       
}
    //删除用户信息
protected void Button2_Click(object sender, EventArgs e)
{
    SqlConnection conn = new SqlConnection();
    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    string str = "select * from userinfo where uname='" + DropDownList3.SelectedValue + "'";
    SqlDataAdapter da = new SqlDataAdapter(str, conn);
    SqlCommandBuilder cb = new SqlCommandBuilder(da);
    DataSet ds = new DataSet();
    da.Fill(ds, "userinfo");//将要删除的记录填充到DataSet对象中
    DataRow myRow = ds.Tables["userinfo"].Rows[0]; //得到要删除的行
    myRow.Delete(); //从数据表中删除行
    DropDownList3.Items.Remove(DropDownList3.Items[DropDownList3.SelectedIndex]);
    da.Update(ds, "userinfo");
    databind();
    Response.Write("<script> alert('记录删除成功!');</script>");
}
protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
{
   
}
protected void Button3_Click(object sender, EventArgs e)
{//添加诗句
    SqlConnection conn = new SqlConnection();
    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    SqlCommand sr = new SqlCommand("select * from Table3", conn);
    SqlDataAdapter da = new SqlDataAdapter(sr);
    DataSet ds = new DataSet();
    da.Fill(ds, "Table3");
    DataRow newRow = ds.Tables["Table3"].NewRow();
    newRow["编号"] = txtbianhao.Text;  //该行的一列的值
    newRow["题目"] = Txttimu.Text;  //该行另外一列的值
    newRow["作者"] = TextBox1.Text; 
    newRow["诗句"] = Txtshiju.Text;
    newRow["句号"] = Txtjuhao.Text;
    ds.Tables["Table3"].Rows.Add(newRow);
    SqlCommandBuilder cb = new SqlCommandBuilder(da);
    da.Update(ds, "Table3");
    bind();
    DropDownList4.Items.Add(txtbianhao.Text);
     
}

protected void Button4_Click4(object sender, EventArgs e)
{//删除诗句
    SqlConnection conn = new SqlConnection();
    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    string str = "select * from Table3 where 编号='" + DropDownList4.SelectedValue + "'";
    SqlDataAdapter da = new SqlDataAdapter(str, conn);
    SqlCommandBuilder cb = new SqlCommandBuilder(da);
    DataSet ds = new DataSet();
    da.Fill(ds, "Table3");//将要删除的记录填充到DataSet对象中
    DataRow myRow = ds.Tables["Table3"].Rows[0]; //得到要删除的行
    myRow.Delete(); //从数据表中删除行
    DropDownList4.Items.Remove(DropDownList4.Items[DropDownList4.SelectedIndex]);
    da.Update(ds, "Table3");
    databind8();
    Response.Write("<script> alert('记录删除成功!');</script>");
}

protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
{//用户信息编辑
    SqlConnection conn = new SqlConnection();
    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    string SelectSql = "select * from userinfo where uname='" + DropDownList3.SelectedValue + "'";
    SqlCommand com = new SqlCommand(SelectSql, conn);
    SqlDataAdapter da = new SqlDataAdapter();
    da.SelectCommand = com;
    DataSet ds = new DataSet();
    da.Fill(ds, "userinfo");
    txtname.Text = ds.Tables["userinfo"].Rows[0][0].ToString();
    txtmima.Text = ds.Tables["userinfo"].Rows[0][1].ToString();
    txtid.Text = ds.Tables["userinfo"].Rows[0][2].ToString();
    txtadd.Text = ds.Tables["userinfo"].Rows[0][3].ToString();
}
protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
{//删除诗句
    SqlConnection conn = new SqlConnection();
    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    string SelectSql = "select * from Table3 where 编号='" + DropDownList4.SelectedValue + "'";
    SqlCommand com = new SqlCommand(SelectSql, conn);
    SqlDataAdapter da = new SqlDataAdapter();
    da.SelectCommand = com;
    DataSet ds = new DataSet();
    da.Fill(ds, "Table3");
    txtbianhao.Text = ds.Tables["Table3"].Rows[0][0].ToString();
    Txttimu.Text = ds.Tables["Table3"].Rows[0][1].ToString();
    TextBox1.Text = ds.Tables["Table3"].Rows[0][2].ToString();
    Txtshiju.Text = ds.Tables["Table3"].Rows[0][3].ToString();
    Txtjuhao.Text = ds.Tables["Table3"].Rows[0][4].ToString();
}
protected void Button5_Click(object sender, EventArgs e)
{//修改诗句
    SqlConnection conn = new SqlConnection();
    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    string SelectSql = "select * from Table3  where 编号='" + DropDownList4.SelectedValue + "'";
    SqlDataAdapter da = new SqlDataAdapter(SelectSql, conn);
    DataSet ds = new DataSet();
    da.Fill(ds, "Table3");
    DataRow MyRow = ds.Tables["Table3"].Rows[0];   //得到要修改的行
    MyRow["编号"] = txtbianhao.Text;    //为相应字段赋以新值
    MyRow["题目"] = Txttimu.Text;
    MyRow["作者"] = TextBox1.Text;
    MyRow["诗句"] = Txtshiju.Text;
    MyRow["句号"] = Txtjuhao.Text;
    SqlCommandBuilder cb = new SqlCommandBuilder(da);
    da.Update(ds, "Table3");			//将DataSet中数据变化提交到数据库（更新数据库）
    Response.Write("<script> alert('更新成功！');</script>");
    databind8();
}
}