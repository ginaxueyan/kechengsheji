﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;



    



public partial class _Default : System.Web.UI.Page
{
  
       
    protected void Page_Load(object sender, EventArgs e)
    {
       


    }

    protected void Button2_Click(object sender, EventArgs e)
    {   //出题
        SqlConnection conn = new SqlConnection();//建立数据库连接对象conn
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        SqlDataAdapter da = new SqlDataAdapter("select * from Table3  where 句号=1 or 句号=3", conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "student");
        Random rn = new Random();
        int n = rn.Next(0, ds.Tables["student"].Rows.Count);
        Session["jh"] = ds.Tables["student"].Rows[n][4].ToString().Trim();
        Session["id"] = ds.Tables["student"].Rows[n][1].ToString().Trim();
        Label1.Text = ds.Tables["student"].Rows[n][3].ToString();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {//提交
        int n = int.Parse(Session["jh"].ToString());
        String m = Session["id"].ToString();
        SqlConnection con = new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();   //连接数据库
        string strsql = "select * from Table3 where  题目='" + m + "'";
        SqlDataAdapter da = new SqlDataAdapter(strsql, con);            //提取数据库中数据
        DataSet ds = new DataSet();
        da.Fill(ds, "sc");
        if (TextBox1.Text == ds.Tables["sc"].Rows[n][3].ToString().Trim())
        {
            TextBox1.Text = "";
            Response.Write("<script>alert('恭喜你，答对了！')</script>");
        }
        else
        {
            Response.Write("<script>alert('错误，请重新输入！')</script>");
            Label2.Text = ds.Tables["sc"].Rows[n][3].ToString().Trim();
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("首页.aspx");
    }
}
