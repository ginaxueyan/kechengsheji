#if !defined(AFX_SEARCHVARIETY_H__452A0E7B_EC51_4C5D_9A31_A0AE172E13BE__INCLUDED_)
#define AFX_SEARCHVARIETY_H__452A0E7B_EC51_4C5D_9A31_A0AE172E13BE__INCLUDED_
#include "Search.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SearchVariety.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSearchVariety dialog

class CSearchVariety : public CDialog
{
// Construction
public:
	CSearchVariety(CWnd* pParent = NULL);   // standard constructor
    CMy1Dlg *FatherDlg;
// Dialog Data
	//{{AFX_DATA(CSearchVariety)
	enum { IDD = IDD_SearchVariety };
	CListCtrl	m_list1;
	CString	m_e1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchVariety)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSearchVariety)
	afx_msg void Onchazhao1();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEARCHVARIETY_H__452A0E7B_EC51_4C5D_9A31_A0AE172E13BE__INCLUDED_)
