// Sta.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "Sta.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSta

CSta::CSta()
{
}

CSta::~CSta()
{
}


BEGIN_MESSAGE_MAP(CSta, CStatic)
	//{{AFX_MSG_MAP(CSta)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSta message handlers

int CSta::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CStatic::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	font.CreatePointFont(400,"����_GB2312");
	SetFont(&font);
	return 0;
}
