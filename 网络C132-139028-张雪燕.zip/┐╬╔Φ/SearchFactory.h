#if !defined(AFX_SEARCHFACTORY_H__36DD1C68_06CC_438B_B006_DF180E20A511__INCLUDED_)
#define AFX_SEARCHFACTORY_H__36DD1C68_06CC_438B_B006_DF180E20A511__INCLUDED_
#include "Search.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SearchFactory.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSearchFactory dialog

class CSearchFactory : public CDialog
{
// Construction
public:
	CSearchFactory(CWnd* pParent = NULL);   // standard constructor
    CMy1Dlg *FatherDlg;
// Dialog Data
	//{{AFX_DATA(CSearchFactory)
	enum { IDD = IDD_SearchFactory };
	CListCtrl	m_list1;
	CString	m_e1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchFactory)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSearchFactory)
	virtual BOOL OnInitDialog();
	afx_msg void Ongongchangchazhao();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEARCHFACTORY_H__36DD1C68_06CC_438B_B006_DF180E20A511__INCLUDED_)
