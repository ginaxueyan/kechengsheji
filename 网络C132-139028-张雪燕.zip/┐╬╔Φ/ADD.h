#if !defined(AFX_ADD_H__ECF76A07_863D_41D9_B2B9_28B102C754A2__INCLUDED_)
#define AFX_ADD_H__ECF76A07_863D_41D9_B2B9_28B102C754A2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ADD.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CADD dialog

class CADD : public CDialog
{
// Construction
public:
	CADD(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CADD)
	enum { IDD = IDD_Add };
	CComboBox	m_var;
	CString	m_variety;
	CString	m_name;
	CString	m_factory;
	CString	m_price;
	CString	m_number;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CADD)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CADD)
	virtual BOOL OnInitDialog();
	afx_msg void Onadd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADD_H__ECF76A07_863D_41D9_B2B9_28B102C754A2__INCLUDED_)
