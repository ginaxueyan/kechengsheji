#if !defined(AFX_DELETE_H__3B3AA6B6_9153_4E3B_AF48_543D371183B1__INCLUDED_)
#define AFX_DELETE_H__3B3AA6B6_9153_4E3B_AF48_543D371183B1__INCLUDED_
#include "1.h"
#include "1Dlg.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Delete.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDelete dialog

class CDelete : public CDialog
{
// Construction
public:
	CDelete(CWnd* pParent = NULL);   // standard constructor
    CFont font;
	CMy1Dlg *FatherDlg;
// Dialog Data
	//{{AFX_DATA(CDelete)
	enum { IDD = IDD_Delete };
	CComboBox	m_newvariety;
	CComboBox	m_variety;
	CString	m_var;
	CString	m_newvar;
	CString	m_edit;
	CString	m_name;
	CString	m_factory;
	CString	m_price;
	CString	m_number;
	CString	m_newname;
	CString	m_newfactory;
	CString	m_newprice;
	CString	m_newnumber;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDelete)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDelete)
	afx_msg void Onxiugai();
	virtual BOOL OnInitDialog();
	afx_msg void Onchaxun();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DELETE_H__3B3AA6B6_9153_4E3B_AF48_543D371183B1__INCLUDED_)
