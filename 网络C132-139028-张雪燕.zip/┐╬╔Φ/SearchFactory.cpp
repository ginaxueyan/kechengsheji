// SearchFactory.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "SearchFactory.h"
#include "Search.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSearchFactory dialog


CSearchFactory::CSearchFactory(CWnd* pParent /*=NULL*/)
	: CDialog(CSearchFactory::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSearchFactory)
	m_e1 = _T("");
	//}}AFX_DATA_INIT
}


void CSearchFactory::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchFactory)
	DDX_Control(pDX, IDC_LIST1, m_list1);
	DDX_Text(pDX, IDC_EDIT1, m_e1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchFactory, CDialog)
	//{{AFX_MSG_MAP(CSearchFactory)
	ON_BN_CLICKED(IDC_gongchangchazhao, Ongongchangchazhao)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchFactory message handlers

BOOL CSearchFactory::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_list1.InsertColumn(0,"��Ʒ����",LVCFMT_LEFT,90);
	m_list1.InsertColumn(1,"����",LVCFMT_LEFT,90);
	m_list1.InsertColumn(2,"����",LVCFMT_LEFT,90);
	m_list1.InsertColumn(3,"�۸�",LVCFMT_LEFT,90);
	m_list1.InsertColumn(4,"�������",LVCFMT_LEFT,90);
	m_list1.SetExtendedStyle(m_list1.GetExtendedStyle()|LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSearchFactory::Ongongchangchazhao() 
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	int a,n=0;
	CString e1;
	for(n;n<=FatherDlg->m_list.GetItemCount();n++)
	{
		e1=FatherDlg->m_list.GetItemText(n,2);
		CString s(e1);
        a=s.Find(m_e1);
			if(a!=-1)
			{
			int nItem=m_list1.InsertItem(m_list1.GetItemCount(),FatherDlg->m_list.GetItemText(n,0));
         	m_list1.SetItemText(nItem,1,FatherDlg->m_list.GetItemText(n,1));
	        m_list1.SetItemText(nItem,2,FatherDlg->m_list.GetItemText(n,2));
	        m_list1.SetItemText(nItem,3,FatherDlg->m_list.GetItemText(n,3));
	        m_list1.SetItemText(nItem,4,FatherDlg->m_list.GetItemText(n,4));
			}		

	UpdateData(0);
	}
}
