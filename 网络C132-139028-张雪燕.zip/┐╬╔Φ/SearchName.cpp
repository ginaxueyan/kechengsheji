// SearchName.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "SearchName.h"
#include "Search.h"
#include "1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSearchName dialog


CSearchName::CSearchName(CWnd* pParent /*=NULL*/)
	: CDialog(CSearchName::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSearchName)
	m_edit = _T("");
	m_name = _T("");
	m_var = _T("");
	m_factory = _T("");
	m_price = _T("");
	m_number = _T("");
	//}}AFX_DATA_INIT
}


void CSearchName::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchName)
	DDX_Text(pDX, IDC_EDIT1, m_edit);
	DDX_Text(pDX, IDC_EDIT2, m_name);
	DDX_Text(pDX, IDC_EDIT3, m_var);
	DDX_Text(pDX, IDC_EDIT4, m_factory);
	DDX_Text(pDX, IDC_EDIT5, m_price);
	DDX_Text(pDX, IDC_EDIT6, m_number);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchName, CDialog)
	//{{AFX_MSG_MAP(CSearchName)
	ON_BN_CLICKED(IDC_chaxun, Onchaxun)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchName message handlers

void CSearchName::Onchaxun() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	int n;
	for(n=0;n<=FatherDlg->m_list.GetItemCount();n++)
{
	if(m_edit==FatherDlg->m_list.GetItemText(n,0))
	{
	
		m_name=FatherDlg->m_list.GetItemText(n,0);
		CString strvariety=FatherDlg->m_list.GetItemText(n,1);
		m_factory=FatherDlg->m_list.GetItemText(n,2);
		m_price=FatherDlg->m_list.GetItemText(n,3);
		m_number=FatherDlg->m_list.GetItemText(n,4);

		if(strvariety=="��ͯ��Ʒ")
			m_var="��ͯ��Ʒ";
		else if(strvariety=="�Ҿ���Ʒ")
			m_var="�Ҿ���Ʒ";
		else if(strvariety=="ʳƷ")
			m_var="ʳƷ";
		else if(strvariety=="������Ʒ")
			m_var="������Ʒ";
		else if(strvariety=="������Ʒ")
			m_var="������Ʒ";
		else
			return;
			
	}
        UpdateData(FALSE);	
}
}
