// Delete.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "Delete.h"
#include "Search.h"
#include "1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDelete dialog


CDelete::CDelete(CWnd* pParent /*=NULL*/)
	: CDialog(CDelete::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDelete)
	m_var = _T("");
	m_newvar = _T("");
	m_edit = _T("");
	m_name = _T("");
	m_factory = _T("");
	m_price = _T("");
	m_number = _T("");
	m_newname = _T("");
	m_newfactory = _T("");
	m_newprice = _T("");
	m_newnumber = _T("");
	//}}AFX_DATA_INIT
}


void CDelete::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDelete)
	DDX_Control(pDX, IDC_COMBO2, m_newvariety);
	DDX_Control(pDX, IDC_COMBO1, m_variety);
	DDX_CBString(pDX, IDC_COMBO1, m_var);
	DDX_CBString(pDX, IDC_COMBO2, m_newvar);
	DDX_Text(pDX, IDC_EDIT1, m_edit);
	DDX_Text(pDX, IDC_EDIT3, m_name);
	DDX_Text(pDX, IDC_EDIT4, m_factory);
	DDX_Text(pDX, IDC_EDIT5, m_price);
	DDX_Text(pDX, IDC_EDIT6, m_number);
	DDX_Text(pDX, IDC_EDIT10, m_newname);
	DDX_Text(pDX, IDC_EDIT12, m_newfactory);
	DDX_Text(pDX, IDC_EDIT13, m_newprice);
	DDX_Text(pDX, IDC_EDIT14, m_newnumber);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDelete, CDialog)
	//{{AFX_MSG_MAP(CDelete)
	ON_BN_CLICKED(IDC_xiugai, Onxiugai)
	ON_BN_CLICKED(IDC_chaxun, Onchaxun)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDelete message handlers

void CDelete::Onxiugai() 
{
	// TODO: Add your control notification handler code here
	for(int n=0;n<=FatherDlg->m_list.GetItemCount();n++)
	{
		if(m_edit==FatherDlg->m_list.GetItemText(n,0))
		{
		
		UpdateData(TRUE);

		FatherDlg->m_list.SetItemText(n,0,m_newname);
		FatherDlg->m_list.SetItemText(n,1,m_newvar);
		FatherDlg->m_list.SetItemText(n,2,m_newfactory);
		FatherDlg->m_list.SetItemText(n,3,m_newprice);
		FatherDlg->m_list.SetItemText(n,4,m_newnumber);
		
		UpdateData(FALSE);
			AfxMessageBox("�޸ĳɹ���");	
		}
		
	}	
}

BOOL CDelete::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_variety.AddString("��ͯ��Ʒ");
	m_variety.AddString("������Ʒ");
	m_variety.AddString("������Ʒ");
	m_variety.AddString("�Ҿ���Ʒ");
	m_variety.AddString("ʳƷ");
	m_variety.SetCurSel(0);
	m_newvariety.AddString("��ͯ��Ʒ");
	m_newvariety.AddString("������Ʒ");
	m_newvariety.AddString("������Ʒ");
	m_newvariety.AddString("�Ҿ���Ʒ");
	m_newvariety.AddString("ʳƷ");
	m_newvariety.SetCurSel(0);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDelete::Onchaxun() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	int n;
	
	for(n=0;n<=FatherDlg->m_list.GetItemCount();n++)
{
	if(m_edit==FatherDlg->m_list.GetItemText(n,0))
	{
	
		m_name=FatherDlg->m_list.GetItemText(n,0);
		CString strvariety=FatherDlg->m_list.GetItemText(n,1);
		m_factory=FatherDlg->m_list.GetItemText(n,2);
		m_price=FatherDlg->m_list.GetItemText(n,3);
		m_number=FatherDlg->m_list.GetItemText(n,4);
		if(strvariety=="��ͯ��Ʒ")
			m_var="��ͯ��Ʒ";
		else if(strvariety=="�Ҿ���Ʒ")
			m_var="�Ҿ���Ʒ";
		else if(strvariety=="ʳƷ")
			m_var="ʳƷ";
		else if(strvariety=="������Ʒ")
			m_var="������Ʒ";
		else if(strvariety=="������Ʒ")
			m_var="������Ʒ";
		else
			return;	
	}


}
UpdateData(FALSE);	
}
