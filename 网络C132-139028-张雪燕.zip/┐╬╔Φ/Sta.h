#if !defined(AFX_STA_H__7ADC4926_7270_4519_BCA7_5F5748DC043C__INCLUDED_)
#define AFX_STA_H__7ADC4926_7270_4519_BCA7_5F5748DC043C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Sta.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSta window

class CSta : public CStatic
{
// Construction
public:
	CSta();
    CFont font;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSta)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSta();

	// Generated message map functions
protected:
	//{{AFX_MSG(CSta)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STA_H__7ADC4926_7270_4519_BCA7_5F5748DC043C__INCLUDED_)
