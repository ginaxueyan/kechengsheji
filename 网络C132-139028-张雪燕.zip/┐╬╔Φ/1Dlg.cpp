// 1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "1Dlg.h"
#include "ADD.h"
#include "Search.h"
#include "Delete.h"
#include "Welcome.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy1Dlg dialog

CMy1Dlg::CMy1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMy1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy1Dlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy1Dlg)
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_STATIC1, m_sta);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy1Dlg, CDialog)
	//{{AFX_MSG_MAP(CMy1Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_add, Onadd)
	ON_BN_CLICKED(IDC_xiugai, Onxiugai)
	ON_BN_CLICKED(IDC_del, Ondel)
	ON_BN_CLICKED(IDC_chazhao, Onchazhao)
	ON_BN_CLICKED(IDC_read, Onread)
	ON_BN_CLICKED(IDC_save, Onsave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy1Dlg message handlers

BOOL CMy1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//Welcome dlg;
     //dlg.DoModal();
	font.CreatePointFont(400,"����_GB2312");
	GetDlgItem(IDC_STATIC1)->SetFont(&font);//ͨ�����صľ���Դ����ڵ���Ԫ�ؽ��в���
	
	m_list.InsertColumn(0,"��Ʒ����",LVCFMT_LEFT,90);
	m_list.InsertColumn(1,"����",LVCFMT_LEFT,90);
	m_list.InsertColumn(2,"����",LVCFMT_LEFT,90);
	m_list.InsertColumn(3,"�۸�",LVCFMT_LEFT,90);
	m_list.InsertColumn(4,"�������",LVCFMT_LEFT,90);
	m_list.SetExtendedStyle(m_list.GetExtendedStyle()|LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMy1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy1Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMy1Dlg::Onadd() 
{
	// TODO: Add your control notification handler code here
	CADD dlg;
if(dlg.DoModal()==IDOK)
{
    UpdateData(TRUE);
	CString variety;
	variety=dlg.m_variety;
	int nItem=m_list.InsertItem(m_list.GetItemCount(),dlg.m_name);
	m_list.SetItemText(nItem,0,dlg.m_name);
	m_list.SetItemText(nItem,1,variety);
	m_list.SetItemText(nItem,2,dlg.m_factory);
	m_list.SetItemText(nItem,3,dlg.m_price);
	m_list.SetItemText(nItem,4,dlg.m_number);
}
}

void CMy1Dlg::Onxiugai() 
{
	// TODO: Add your control notification handler code here
	CDelete dlg;
    dlg.FatherDlg=this;
	if(dlg.DoModal()==IDOK)
		return;
}

void CMy1Dlg::Ondel() 
{
	// TODO: Add your control notification handler code here
	int nSel=m_list.GetNextItem(-1,LVNI_SELECTED);//�����û�������κε�״̬��־����ô����������һ�ʼ��
	if(nSel==-1)
		return;
	m_list.DeleteItem(nSel);
}

void CMy1Dlg::Onchazhao() 
{
	// TODO: Add your control notification handler code here
	CSearch dlg;
    dlg.DoModal();
}

void CMy1Dlg::Onread() 
{
	// TODO: Add your control notification handler code here
	CFile file;
	static LONG l=0;
	if(file.Open("��Ʒ��Ϣ.txt",CFile::modeRead))
	{
	
		file.Seek(l,CFile::begin);
		if(file.GetLength()==l)
		{
			MessageBox("��ȡ��ϣ�");
			return;
		}
		for(int i=0;1;i++)
		{
		char t;
		file.Read(&t,1);
		UINT len=t;
		char* p=new char[len+1];
		file.Read(p,len);
		p[len]=0;
		LPTSTR lpszText =(LPTSTR)(LPCTSTR)p;
		m_list.InsertItem(i,p);
		delete[] p;
		l=file.GetPosition();
				for(int j=1;j<10;j++)
			{
				file.Read(&t,1);
				len=t;
				p=new char[len+1];
				file.Read(p,len);
				p[len]=0;
				lpszText =(LPTSTR)(LPCTSTR)p;
				l=file.GetPosition();
				m_list.SetItemText(i,j,lpszText);
				delete[] p;
				l=file.GetPosition();
				UpdateData(0);
			}
		
			if(file.GetLength()==l)
			{
				MessageBox("��ȡ��ϣ�");
				return;
			}
		}
		file.Close();
	}
}

void CMy1Dlg::Onsave() 
{
	// TODO: Add your control notification handler code here
	CFile file;
	CMy1Dlg obj;
	if(file.Open("��Ʒ��Ϣ.txt",CFile::modeCreate | CFile::modeNoTruncate| CFile::modeWrite ))   //open�����βΣ����������ڶ��������������ʣ��ֱ��ǣ�û�������ļ��򴴽��ļ�����ֹ����ԭ�����ݣ�д�������
	{
	
		file.SeekToEnd();    //�ļ�λ��ָ���ƶ����ĵ���ĩβ����ʼд�����
		int len_name,len_variety,len_factory,len_price,len_number; //���ڴ��name�ĳ���
		CString str_name,str_variety,str_factory,str_price,str_number;
		int nItem=m_list.GetItemCount();
		for(int i=0;i<nItem;i++)
		{	
			//����Ʒ����
			str_name=m_list.GetItemText(i,0);
			len_name=str_name.GetLength();
			file.Write(&len_name,1);
			file.Write(str_name,len_name);
			//������
			str_variety=m_list.GetItemText(i,1);
			len_variety=str_variety.GetLength();
			file.Write(&len_variety,1);
			file.Write(str_variety,len_variety);
			//�泧��
			str_factory=m_list.GetItemText(i,2);
			len_factory=str_factory.GetLength();
			file.Write(&len_factory,1);
			file.Write(str_factory,len_factory);
			//��۸�
			str_price=m_list.GetItemText(i,3);
			len_price=str_price.GetLength();
			file.Write(&len_price,1);
			file.Write(str_price,len_price);
			//��������
			str_number=m_list.GetItemText(i,4);
			len_number=str_number.GetLength();
			file.Write(&len_number,1);
			file.Write(str_number,len_number);

			}
	}
}
