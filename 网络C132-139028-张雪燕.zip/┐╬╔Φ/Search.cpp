// Search.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "Search.h"
#include"SearchName.h"
#include"SearchFactory.h"
#include"SearchVariety.h"
#include <afxwin.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSearch dialog


CSearch::CSearch(CWnd* pParent /*=NULL*/)
	: CDialog(CSearch::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSearch)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSearch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearch)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearch, CDialog)
	//{{AFX_MSG_MAP(CSearch)
	ON_BN_CLICKED(IDC_SearchName, OnSearchName)
	ON_BN_CLICKED(IDC_SearchFactory, OnSearchFactory)
	ON_BN_CLICKED(IDC_SearchVariety, OnSearchVariety)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearch message handlers

void CSearch::OnSearchName() 
{
	// TODO: Add your control notification handler code here
	CSearchName dlg;
    dlg.FatherDlg=(CMy1Dlg*)GetParent();
	
	if(dlg.DoModal()==IDOK)
		return;
}

void CSearch::OnSearchFactory() 
{
	// TODO: Add your control notification handler code here
	CSearchFactory dlg;
	dlg.FatherDlg=(CMy1Dlg*)GetParent();
	
	if(dlg.DoModal()==IDOK)
		return;
}

void CSearch::OnSearchVariety() 
{
	// TODO: Add your control notification handler code here
	CSearchVariety dlg;
    dlg.FatherDlg=(CMy1Dlg*)GetParent();//ָ��ǰ���ڵĸ����ڵ�ָ��
	
	if(dlg.DoModal()==IDOK)
		return;
}
