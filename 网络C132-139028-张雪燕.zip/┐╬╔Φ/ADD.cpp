// ADD.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "ADD.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CADD dialog


CADD::CADD(CWnd* pParent /*=NULL*/)
	: CDialog(CADD::IDD, pParent)
{
	//{{AFX_DATA_INIT(CADD)
	m_variety = _T("");
	m_name = _T("");
	m_factory = _T("");
	m_price = _T("");
	m_number = _T("");
	//}}AFX_DATA_INIT
}


void CADD::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CADD)
	DDX_Control(pDX, IDC_COMBO1, m_var);
	DDX_CBString(pDX, IDC_COMBO1, m_variety);
	DDX_Text(pDX, IDC_EDIT1, m_name);
	DDX_Text(pDX, IDC_EDIT7, m_factory);
	DDX_Text(pDX, IDC_EDIT8, m_price);
	DDX_Text(pDX, IDC_EDIT9, m_number);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CADD, CDialog)
	//{{AFX_MSG_MAP(CADD)
	ON_BN_CLICKED(IDC_add, Onadd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CADD message handlers

BOOL CADD::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_var.AddString("��ͯ��Ʒ");
	m_var.AddString("�Ҿ���Ʒ");
	m_var.AddString("ʳƷ");
	m_var.AddString("������Ʒ");
	m_var.AddString("������Ʒ");
	m_var.SetCurSel(0);	//��ǰѡ��
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CADD::Onadd() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_name.IsEmpty()||m_factory.IsEmpty())
	{
		MessageBox("������������Ϣ��");
		return;
	}
	CDialog::OnOK();
}
