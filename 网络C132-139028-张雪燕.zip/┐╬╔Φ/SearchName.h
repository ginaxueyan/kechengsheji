#if !defined(AFX_SEARCHNAME_H__B3EFA47B_41A7_42AD_9995_45AD9245E0BE__INCLUDED_)
#define AFX_SEARCHNAME_H__B3EFA47B_41A7_42AD_9995_45AD9245E0BE__INCLUDED_
#include "1.h"
#include "1Dlg.h"
#include "Search.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SearchName.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSearchName dialog

class CSearchName : public CDialog
{
// Construction
public:
	CSearchName(CWnd* pParent = NULL);   // standard constructor
    CMy1Dlg *FatherDlg;
// Dialog Data
	//{{AFX_DATA(CSearchName)
	enum { IDD = IDD_SearchName };
	CString	m_edit;
	CString	m_name;
	CString	m_var;
	CString	m_factory;
	CString	m_price;
	CString	m_number;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchName)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSearchName)
	afx_msg void Onchaxun();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEARCHNAME_H__B3EFA47B_41A7_42AD_9995_45AD9245E0BE__INCLUDED_)
