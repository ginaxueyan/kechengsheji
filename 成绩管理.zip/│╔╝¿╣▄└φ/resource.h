//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by �ɼ�����.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MY_DIALOG                   102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDC_LIST1                       1000
#define IDC_EDIT1                       1001
#define IDC_xuehao                      1001
#define IDC_EDIT2                       1002
#define IDC_xingming                    1002
#define IDC_BUTTON1                     1003
#define IDC_EDIT6                       1003
#define IDC_find                        1003
#define IDC_EDIT3                       1004
#define IDC_pingjun                     1004
#define IDC_EDIT4                       1005
#define IDC_max                         1005
#define IDC_EDIT5                       1006
#define IDC_bujige                      1006
#define IDC_BUTTON2                     1007
#define IDC_EDIT7                       1007
#define IDC_ying2                       1007
#define IDC_math                        1007
#define IDC_BUTTON3                     1008
#define IDC_EDIT8                       1008
#define IDC_ji                          1008
#define IDC_english                     1008
#define IDC_BUTTON4                     1009
#define IDC_computer                    1009
#define IDC_BUTTON5                     1010
#define IDC_add                         1010
#define IDC_BUTTON6                     1011
#define IDC_delete                      1011
#define IDC_BUTTON7                     1012
#define IDC_liulan                      1012
#define IDC_BUTTON8                     1013
#define IDC_change                      1013
#define IDC_BUTTON9                     1014
#define IDC_save                        1014
#define IDC_EDIT9                       1015
#define IDC_shu                         1015
#define IDC_EDIT10                      1016
#define IDC_ji2                         1016
#define IDC_class                       1017
#define IDC_id                          1018
#define IDC_name                        1019
#define IDC_shu2                        1020
#define IDC_ying                        1021
#define IDC_sex                         1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
