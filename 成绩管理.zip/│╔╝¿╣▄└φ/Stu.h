// Stu.h: interface for the CStu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STU_H__71AA26D8_19E2_4738_B807_4B2B25D01DB2__INCLUDED_)
#define AFX_STU_H__71AA26D8_19E2_4738_B807_4B2B25D01DB2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CStu  
{
public:
	CStu();
	virtual ~CStu();
    int id;
	CString name;
	CString mclass;
	CString sex;
	int ji;
	int ji2;
	int shu;
	int shu2;
	int ying;
	int ying2;
};

#endif // !defined(AFX_STU_H__71AA26D8_19E2_4738_B807_4B2B25D01DB2__INCLUDED_)
