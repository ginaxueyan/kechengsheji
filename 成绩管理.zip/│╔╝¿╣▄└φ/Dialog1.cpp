// Dialog1.cpp : implementation file
//

#include "stdafx.h"
#include "�ɼ�����.h"
#include "Dialog1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialog1 dialog


CDialog1::CDialog1(CWnd* pParent /*=NULL*/)
	: CDialog(CDialog1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialog1)
	m_class = _T("");
	m_id = 0;
	m_ji = 0;
	m_ji2 = 0;
	m_shu = 0;
	m_shu2 = 0;
	m_ying = 0;
	m_ying2 = 0;
	m_name = _T("");
	m_sex = _T("");
	//}}AFX_DATA_INIT
}


void CDialog1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialog1)
	DDX_CBString(pDX, IDC_class, m_class);
	DDX_Text(pDX, IDC_id, m_id);
	DDX_Text(pDX, IDC_ji, m_ji);
	DDX_Text(pDX, IDC_ji2, m_ji2);
	DDX_Text(pDX, IDC_shu, m_shu);
	DDX_Text(pDX, IDC_shu2, m_shu2);
	DDX_Text(pDX, IDC_ying, m_ying);
	DDX_Text(pDX, IDC_ying2, m_ying2);
	DDX_Text(pDX, IDC_name, m_name);
	DDX_CBString(pDX, IDC_sex, m_sex);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialog1, CDialog)
	//{{AFX_MSG_MAP(CDialog1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialog1 message handlers

void CDialog1::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	if((m_shu2==5||m_shu2==0)&&(m_ying2==4||m_ying2==0)&&(m_ji2==3||m_ji2==0))
	       CDialog::OnOK();
	else
		MessageBox("����������ѧ��");
}