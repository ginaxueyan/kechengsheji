#if !defined(AFX_DIALOG1_H__26E8AD46_3809_4250_B74B_54C51EA3CD54__INCLUDED_)
#define AFX_DIALOG1_H__26E8AD46_3809_4250_B74B_54C51EA3CD54__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dialog1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialog1 dialog

class CDialog1 : public CDialog
{
// Construction
public:
	CDialog1(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialog1)
	enum { IDD = IDD_DIALOG1 };
	CString	m_class;
	int		m_id;
	int		m_ji;
	int		m_ji2;
	int		m_shu;
	int		m_shu2;
	int		m_ying;
	int		m_ying2;
	CString	m_name;
	CString	m_sex;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialog1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialog1)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOG1_H__26E8AD46_3809_4250_B74B_54C51EA3CD54__INCLUDED_)
