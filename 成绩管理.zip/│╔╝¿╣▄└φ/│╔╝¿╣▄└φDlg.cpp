// �ɼ�����Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "�ɼ�����.h"
#include "�ɼ�����Dlg.h"

#include "Stu.h"
#include "Dialog1.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg dialog

CMyDlg::CMyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDlg)
	m_bujige = 0;
	m_max = 0;
	m_pingjun = 0;
	m_xingming = _T("");
	m_xuehao = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDlg)
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX, IDC_bujige, m_bujige);
	DDX_Text(pDX, IDC_max, m_max);
	DDX_Text(pDX, IDC_pingjun, m_pingjun);
	DDX_Text(pDX, IDC_xingming, m_xingming);
	DDX_Text(pDX, IDC_xuehao, m_xuehao);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyDlg, CDialog)
	//{{AFX_MSG_MAP(CMyDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_add, Onadd)
	ON_BN_CLICKED(IDC_change, Onchange)
	ON_BN_CLICKED(IDC_computer, Oncomputer)
	ON_BN_CLICKED(IDC_delete, Ondelete)
	ON_BN_CLICKED(IDC_english, Onenglish)
	ON_BN_CLICKED(IDC_find, Onfind)
	ON_BN_CLICKED(IDC_liulan, Onliulan)
	ON_BN_CLICKED(IDC_save, Onsave)
	ON_BN_CLICKED(IDC_math, Onmath)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg message handlers

BOOL CMyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	CRect rt;
	m_list.GetWindowRect(&rt);
	m_list.InsertColumn (0,"����",LVCFMT_LEFT,rt.Width()/10);
	m_list.InsertColumn (1,"ѧ��",LVCFMT_LEFT,rt.Width()/10);
    m_list.InsertColumn (2,"�Ա�",LVCFMT_LEFT,rt.Width()/10);
	m_list.InsertColumn (3,"�༶",LVCFMT_LEFT,rt.Width()/8);
	m_list.InsertColumn (4,"��ѧ",LVCFMT_LEFT,rt.Width()/10);
	m_list.InsertColumn (5,"ѧ��",LVCFMT_LEFT,rt.Width()/10);
    m_list.InsertColumn (6,"Ӣ��",LVCFMT_LEFT,rt.Width()/10);
    m_list.InsertColumn (7,"ѧ��",LVCFMT_LEFT,rt.Width()/10);
	m_list.InsertColumn (8,"�����",LVCFMT_LEFT,rt.Width()/10);
	m_list.InsertColumn (9,"ѧ��",LVCFMT_LEFT,rt.Width()/10);
    
	DWORD style=m_list.GetExtendedStyle();
	style =style | LVS_EX_FULLROWSELECT |LVS_EX_GRIDLINES;
	m_list.SetExtendedStyle(style);
    
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMyDlg::Onadd() 
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	CStu stu;
	CDialog1 dlg;
	int f=dlg.DoModal();
    
	if(f==IDOK)
	{
        stu.name=dlg.m_name;
    	stu.id=dlg.m_id;
	    stu.sex=dlg.m_sex;
    	stu.mclass=dlg.m_class;
	    stu.shu=dlg.m_shu;
    	stu.shu2=dlg.m_shu2;
    	stu.ying=dlg.m_ying;
     	stu.ying2=dlg.m_ying2;
    	stu.ji=dlg.m_ji;
     	stu.ji2=dlg.m_ji2;
        students.Add (stu);
        MessageBox("¼��ɹ�!");  
	}
	UpdateData(0);
}

void CMyDlg::Onchange() 
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	CStu stu;
	CDialog1 dlg;
	CString shu,shu2,ying,ying2,ji,ji2,id;
    int ri=m_list.GetNextItem(-1,LVIS_SELECTED);//������LVIS_SELECTED״̬��־��������û�������κε�״̬��־����ô����������һ�ʼ�� 
	if(ri==-1)
		return;
	dlg.m_id=students[ri].id;
	dlg.m_name=students[ri].name;
	dlg.m_sex=students[ri].sex;
	dlg.m_class=students[ri].mclass;
	dlg.m_shu=students[ri].shu;
	dlg.m_shu2=students[ri].shu2;
	dlg.m_ying=students[ri].ying;
    dlg.m_ying2=students[ri].ying2;
	dlg.m_ji=students[ri].ji;
	dlg.m_ji2=students[ri].ji2;
	int f=dlg.DoModal();
	if(f==IDOK)
	{ 
        shu.Format("%d",dlg.m_shu);
	    shu2.Format("%d",dlg.m_shu2);
	    ying.Format("%d",dlg.m_ying);
    	ying2.Format("%d",dlg.m_ying2);
    	ji.Format("%d",dlg.m_ji);
    	ji2.Format("%d",dlg.m_ji2);
        id.Format("%d",dlg.m_id);
        m_list.SetItemText(ri,1,dlg.m_name);
        m_list.SetItemText(ri,1,id);
		m_list.SetItemText(ri,2,dlg.m_sex);
		m_list.SetItemText(ri,3,dlg.m_class);
		m_list.SetItemText(ri,4,shu);
		m_list.SetItemText(ri,5,shu2);
		m_list.SetItemText(ri,6,ying);
		m_list.SetItemText(ri,7,ying2);
		m_list.SetItemText(ri,8,ji);
		m_list.SetItemText(ri,9,ji2);

		students[ri].id=dlg.m_id;
	    students[ri].name=dlg.m_name;
		students[ri].sex=dlg.m_sex;
	    students[ri].mclass=dlg.m_class;
    	students[ri].shu=dlg.m_shu;
    	students[ri].shu2=dlg.m_shu2;
    	students[ri].ying=dlg.m_ying;
        students[ri].ying2=dlg.m_ying2;
    	students[ri].ji=dlg.m_ji;
    	students[ri].ji2=dlg.m_ji2;
	}
}

void CMyDlg::Oncomputer() 
{
	// TODO: Add your control notification handler code here
    int str=0,k=0,s=0;
	for(int i=0;i<students.GetSize();i++)
	{
		str+=students[i].ji;
	}
	m_pingjun=str/students.GetSize();
	for(int j=0;j<students.GetSize();j++)
	{
        if(students[j].ji<60)
			k++;
	}
	m_bujige=k;
	for(int q=0;q<students.GetSize();q++)
	{
		if(students[q].ji>s)
			s=students[q].ji;
	}
	m_max=s;
	UpdateData(0);
}

void CMyDlg::Ondelete() 
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	m_list.DeleteAllItems();//ɾ���б��е�����Ԫ��
	int rawi=m_list.GetNextItem(-1,LVIS_SELECTED);//������LVIS_SELECTED״̬��־��������û�������κε�״̬��־����ô����������һ�ʼ�� 
	if(rawi==-1)
		return;
	m_list.DeleteItem(rawi);
}

void CMyDlg::Onenglish() 
{
	// TODO: Add your control notification handler code here
	int str=0,k=0,s=0;
	for(int i=0;i<students.GetSize();i++)
	{
		str+=students[i].ying;
	}
	m_pingjun=str/students.GetSize();
	for(int j=0;j<students.GetSize();j++)
	{
        if(students[j].ying<60)
			k++;
	}
	m_bujige=k;
	for(int q=0;q<students.GetSize();q++)
	{
		if(students[q].ying>s)
			s=students[q].ying;
	}
	m_max=s;
	UpdateData(0);
}

void CMyDlg::Onfind() 
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	m_list.DeleteAllItems();
	int rawi;
	CString shu,shu2,ying,ying2,ji,ji2,id;
	//m_list.Removeall();
	for(int i=0;i<students.GetSize();i++)
	{  
      if(m_xingming==students[i].name&&m_xuehao==students[i].id)
	  {
	    rawi=m_list.InsertItem(m_list.GetItemCount(),students[i].name,0);
        shu.Format("%d",students[i].shu);
	    shu2.Format("%d",students[i].shu2);
	    ying.Format("%d",students[i].ying);
    	ying2.Format("%d",students[i].ying2);
    	ji.Format("%d",students[i].ji);
    	ji2.Format("%d",students[i].ji2);
        id.Format("%d",students[i].id);

        m_list.SetItemText(rawi,1,id);
		m_list.SetItemText(rawi,2,students[i].sex);
		m_list.SetItemText(rawi,3,students[i].mclass);
		m_list.SetItemText(rawi,4,shu);
		m_list.SetItemText(rawi,5,shu2);
		m_list.SetItemText(rawi,6,ying);
		m_list.SetItemText(rawi,7,ying2);
		m_list.SetItemText(rawi,8,ji);
		m_list.SetItemText(rawi,9,ji2);
	  }
	}
    UpdateData(0);
}

void CMyDlg::Onliulan() 
{
	// TODO: Add your control notification handler code here
	
	int rawi;
	m_list.DeleteAllItems();//ɾ��������
	students.RemoveAll();

	CString shu,shu2,ying,ying2,ji,ji2,id;
	CFile myfile;
    
	CArchive ar(&myfile,CArchive::load);
	if(myfile.Open("aa.txt",CFile::modeRead)!=TRUE)
	{
		MessageBox("�ļ��޷���");
			return;
	}
	int k;
	ar>>k;
	for(int i=0;i<k;i++)
	{  
		CStu stu;
		ar>>stu.name;
		ar>>stu.id;
		ar>>stu.sex;
		ar>>stu.mclass;
		ar>>stu.shu;
		ar>>stu.shu2;
		ar>>stu.ying;
		ar>>stu.ying2;
		ar>>stu.ji;
		ar>>stu.ji2;

	    rawi=m_list.InsertItem(m_list.GetItemCount(),stu.name,0);
		id.Format("%d",stu.id);
        shu.Format("%d",stu.shu);
	    shu2.Format("%d",stu.shu2);
	    ying.Format("%d",stu.ying);
    	ying2.Format("%d",stu.ying2);
    	ji.Format("%d",stu.ji);
    	ji2.Format("%d",stu.ji2);
        
        m_list.SetItemText(rawi,1,id);
		m_list.SetItemText(rawi,2,stu.sex);
		m_list.SetItemText(rawi,3,stu.mclass);
		m_list.SetItemText(rawi,4,shu);
		m_list.SetItemText(rawi,5,shu2);
		m_list.SetItemText(rawi,6,ying);
		m_list.SetItemText(rawi,7,ying2);
		m_list.SetItemText(rawi,8,ji);
		m_list.SetItemText(rawi,9,ji2);
		students.Add(stu);
	}
    UpdateData(0);
}

void CMyDlg::Onsave() 
{
	// TODO: Add your control notification handler code here
	CFile myfile;
	if(myfile.Open("aa.txt",CFile::modeWrite|CFile::modeCreate)!=TRUE)
	{
		MessageBox("�ļ���ʧ�ܣ�");
		return;
	}
	CArchive ar(&myfile,CArchive::store);//����һ��CArhcive����
	int cnt=students.GetSize();
	ar<<cnt;
	CString id,shu,shu2,ying,ying2,ji,ji2;
	for(int i=0;i<cnt;i++)
	{
		ar<<students[i].name;
		ar<<students[i].id;
		ar<<students[i].sex;
		ar<<students[i].mclass;
		ar<<students[i].shu;
		ar<<students[i].shu2;
		ar<<students[i].ying;
		ar<<students[i].ying2;
		ar<<students[i].ji;
		ar<<students[i].ji2;
	}
	ar.Close();//�ر�CArchive����
	myfile.Close();
}

void CMyDlg::Onmath() 
{
	// TODO: Add your control notification handler code here
    int str=0,k=0,s=0;
	for(int i=0;i<students.GetSize();i++)
	{
		str+=students[i].shu;
	}
	m_pingjun=str/students.GetSize();
	for(int j=0;j<students.GetSize();j++)
	{
        if(students[j].shu<60)
			k++;
	}
	m_bujige=k;
	for(int q=0;q<students.GetSize();q++)
	{
		if(students[q].shu>s)
			s=students[q].shu;
	}
	m_max=s;
	UpdateData(0);
}
